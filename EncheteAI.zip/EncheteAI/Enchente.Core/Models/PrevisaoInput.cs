﻿namespace Enchente.Core.Models;


public class PrevisaoInput
{
    public float Temperatura { get; set; }
    public float Umidade { get; set; }
}


public class PrevisaoOutput
{
    public float RiscoEnchente { get; set; }
}

