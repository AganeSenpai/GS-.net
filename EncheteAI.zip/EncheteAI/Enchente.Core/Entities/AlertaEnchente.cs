﻿namespace Enchente.Core.Entities;

public enum NivelAlerta
{
    Baixo,
    Medio,
    Alto
}

public class AlertaEnchente
{
    public int Id { get; set; }
    public int CidadeId { get; set; }
    public Cidade Cidade { get; set; } = null!;
    public DateTime DataHora { get; set; }
    public NivelAlerta NivelAlerta { get; set; }
    public string Descricao { get; set; } = null!;
}

