﻿namespace Enchente.Core.Entities;

public class Cidade
{
    public int Id { get; set; }
    public string Nome { get; set; } = null!;
    public string Estado { get; set; } = null!;
    public double Latitude { get; set; }
    public double Longitude { get; set; }
}

