﻿namespace Enchente.Core.Entities;

public class PrevisaoClima
{
    public int Id { get; set; }
    public int CidadeId { get; set; }
    public Cidade Cidade { get; set; } = null!;
    public DateTime DataHora { get; set; }
    public float Temperatura { get; set; }
    public float Chuva { get; set; }
    public float Umidade { get; set; }
}

