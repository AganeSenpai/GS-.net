﻿using Enchente.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Enchente.Core.Interfaces;

public interface IAlertaEnchenteRepository
{
    Task<IEnumerable<AlertaEnchente>> GetAllAsync();
    Task<AlertaEnchente?> GetByIdAsync(int id);
    Task AddAsync(AlertaEnchente alerta);
    Task UpdateAsync(AlertaEnchente alerta);
    Task DeleteAsync(int id);
}

