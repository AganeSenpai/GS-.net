﻿namespace Enchente.Core.Interfaces;
public interface IMessagingService
{
    void SendMessage(string queueName, string message);
}
