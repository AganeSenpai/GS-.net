﻿using Enchente.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Enchente.Core.Interfaces;

public interface IPrevisaoClimaRepository
{
    Task<IEnumerable<PrevisaoClima>> GetAllAsync();
    Task<PrevisaoClima?> GetByIdAsync(int id);
    Task AddAsync(PrevisaoClima previsao);
    Task UpdateAsync(PrevisaoClima previsao);
    Task DeleteAsync(int id);
}

