﻿using Microsoft.ML;
using Enchente.Core.Models;

namespace Enchente.Infrastructure.Services;

public class MLPredictionService
{
    private readonly MLContext _mlContext;
    private PredictionEngine<PrevisaoInput, PrevisaoOutput> _predictionEngine;

    public MLPredictionService()
    {
        _mlContext = new MLContext();

        // Exemplo: Treinar modelo simples (deve salvar e carregar em cenário real)
        var samples = new[]
        {
            new PrevisaoInput { Temperatura = 30, Umidade = 90 },
            new PrevisaoInput { Temperatura = 25, Umidade = 80 }
        };

        var data = _mlContext.Data.LoadFromEnumerable(samples);
        var pipeline = _mlContext.Transforms.Concatenate("Features", nameof(PrevisaoInput.Temperatura), nameof(PrevisaoInput.Umidade))
            .Append(_mlContext.Regression.Trainers.Sdca());

        var model = pipeline.Fit(data);
        _predictionEngine = _mlContext.Model.CreatePredictionEngine<PrevisaoInput, PrevisaoOutput>(model);
    }

    public PrevisaoOutput Predict(PrevisaoInput input)
    {
        return _predictionEngine.Predict(input);
    }
}

