﻿using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Enchente.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Enchente.Infrastructure.Repositories;

public class AlertaEnchenteRepository : IAlertaEnchenteRepository
{
    private readonly EnchenteDbContext _context;

    public AlertaEnchenteRepository(EnchenteDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<AlertaEnchente>> GetAllAsync()
    {
        return await _context.AlertasEnchente.Include(a => a.Cidade).ToListAsync();
    }

    public async Task<AlertaEnchente?> GetByIdAsync(int id)
    {
        return await _context.AlertasEnchente.Include(a => a.Cidade).FirstOrDefaultAsync(a => a.Id == id);
    }

    public async Task AddAsync(AlertaEnchente alerta)
    {
        await _context.AlertasEnchente.AddAsync(alerta);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(AlertaEnchente alerta)
    {
        _context.AlertasEnchente.Update(alerta);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var alerta = await _context.AlertasEnchente.FindAsync(id);
        if (alerta != null)
        {
            _context.AlertasEnchente.Remove(alerta);
            await _context.SaveChangesAsync();
        }
    }
}
