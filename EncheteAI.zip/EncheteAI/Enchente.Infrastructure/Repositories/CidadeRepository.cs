﻿using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Enchente.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Enchente.Infrastructure.Repositories;

public class CidadeRepository : ICidadeRepository
{
    private readonly EnchenteDbContext _context;

    public CidadeRepository(EnchenteDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Cidade>> GetAllAsync()
    {
        return await _context.Cidades.ToListAsync();
    }

    public async Task<Cidade?> GetByIdAsync(int id)
    {
        return await _context.Cidades.FindAsync(id);
    }

    public async Task AddAsync(Cidade cidade)
    {
        await _context.Cidades.AddAsync(cidade);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(Cidade cidade)
    {
        _context.Cidades.Update(cidade);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var cidade = await _context.Cidades.FindAsync(id);
        if (cidade != null)
        {
            _context.Cidades.Remove(cidade);
            await _context.SaveChangesAsync();
        }
    }
}

