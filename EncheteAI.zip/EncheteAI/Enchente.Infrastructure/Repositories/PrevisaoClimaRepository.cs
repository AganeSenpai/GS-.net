﻿using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Enchente.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace Enchente.Infrastructure.Repositories;

public class PrevisaoClimaRepository : IPrevisaoClimaRepository
{
    private readonly EnchenteDbContext _context;

    public PrevisaoClimaRepository(EnchenteDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<PrevisaoClima>> GetAllAsync()
    {
        return await _context.PrevisoesClima.Include(p => p.Cidade).ToListAsync();
    }

    public async Task<PrevisaoClima?> GetByIdAsync(int id)
    {
        return await _context.PrevisoesClima.Include(p => p.Cidade).FirstOrDefaultAsync(p => p.Id == id);
    }

    public async Task AddAsync(PrevisaoClima previsao)
    {
        await _context.PrevisoesClima.AddAsync(previsao);
        await _context.SaveChangesAsync();
    }

    public async Task UpdateAsync(PrevisaoClima previsao)
    {
        _context.PrevisoesClima.Update(previsao);
        await _context.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var previsao = await _context.PrevisoesClima.FindAsync(id);
        if (previsao != null)
        {
            _context.PrevisoesClima.Remove(previsao);
            await _context.SaveChangesAsync();
        }
    }
}

