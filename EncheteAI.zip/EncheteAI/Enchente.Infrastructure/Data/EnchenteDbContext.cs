﻿using Enchente.Core.Entities;
using Microsoft.EntityFrameworkCore;

namespace Enchente.Infrastructure.Data;

public class EnchenteDbContext : DbContext
{
    public EnchenteDbContext(DbContextOptions<EnchenteDbContext> options) : base(options)
    {
    }

    public DbSet<Cidade> Cidades { get; set; } = null!;
    public DbSet<AlertaEnchente> AlertasEnchente { get; set; } = null!;
    public DbSet<PrevisaoClima> PrevisoesClima { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AlertaEnchente>()
            .HasOne(a => a.Cidade)
            .WithMany()
            .HasForeignKey(a => a.CidadeId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<PrevisaoClima>()
            .HasOne(p => p.Cidade)
            .WithMany()
            .HasForeignKey(p => p.CidadeId)
            .OnDelete(DeleteBehavior.Cascade);

        base.OnModelCreating(modelBuilder);
    }
}

