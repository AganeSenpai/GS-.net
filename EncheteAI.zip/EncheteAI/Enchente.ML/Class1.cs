﻿namespace Enchente.ML
{
    public class Class1
    {

    }
}
