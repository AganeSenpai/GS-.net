using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;

[ApiController]
[Route("api/[controller]")]
public class CidadeController : ControllerBase
{
    private readonly ICidadeRepository _cidadeRepo;

    public CidadeController(ICidadeRepository cidadeRepo)
    {
        _cidadeRepo = cidadeRepo;
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetById(int id)
    {
        var cidade = await _cidadeRepo.GetByIdAsync(id);
        if (cidade == null)
            return NotFound();

        var response = new
        {
            data = cidade,
            links = new[]
            {
                new { rel = "self", href = Url.Action(nameof(GetById), new { id }), method = "GET" },
                new { rel = "update", href = Url.Action(nameof(Update), new { id }), method = "PUT" },
                new { rel = "delete", href = Url.Action(nameof(Delete), new { id }), method = "DELETE" }
            }
        };

        return Ok(response);
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Cidade>>> GetAll()
        => Ok(await _cidadeRepo.GetAllAsync());

    [HttpPost]
    public async Task<IActionResult> Create(Cidade cidade)
    {
        await _cidadeRepo.AddAsync(cidade);
        return CreatedAtAction(nameof(GetById), new { id = cidade.Id }, cidade);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, Cidade cidade)
    {
        if (id != cidade.Id) return BadRequest();
        await _cidadeRepo.UpdateAsync(cidade);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _cidadeRepo.DeleteAsync(id);
        return NoContent();
    }
}
