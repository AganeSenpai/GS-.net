﻿using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class AlertaEnchenteController : ControllerBase
{
    private readonly IAlertaEnchenteRepository _repo;
    private readonly IMessagingService _messaging;

    public AlertaEnchenteController(IAlertaEnchenteRepository repo, IMessagingService messaging)
    {
        _repo = repo;
        _messaging = messaging;
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetById(int id)
    {
        var alerta = await _repo.GetByIdAsync(id);
        if (alerta == null) return NotFound();

        var response = new
        {
            data = alerta,
            links = new[]
            {
                new { rel = "self", href = Url.Action(nameof(GetById), new { id }), method = "GET" },
                new { rel = "update", href = Url.Action(nameof(Update), new { id }), method = "PUT" },
                new { rel = "delete", href = Url.Action(nameof(Delete), new { id }), method = "DELETE" }
            }
        };

        return Ok(response);
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<AlertaEnchente>>> GetAll()
        => Ok(await _repo.GetAllAsync());

    [HttpPost]
    public async Task<IActionResult> Create(AlertaEnchente alerta)
    {
        await _repo.AddAsync(alerta);

        
        var message = $"Novo alerta de enchente criado para cidade {alerta.CidadeId} com severidade {alerta.NivelAlerta}";
        _messaging.SendMessage("alertas-enchente", message);

        return CreatedAtAction(nameof(GetById), new { id = alerta.Id }, alerta);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, AlertaEnchente alerta)
    {
        if (id != alerta.Id) return BadRequest();
        await _repo.UpdateAsync(alerta);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _repo.DeleteAsync(id);
        return NoContent();
    }
}
