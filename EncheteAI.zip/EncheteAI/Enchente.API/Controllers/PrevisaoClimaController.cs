﻿using Enchente.Core.Entities;
using Enchente.Core.Interfaces;
using Enchente.Core.Models;
using Enchente.Infrastructure.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

[ApiController]
[Route("api/[controller]")]
public class PrevisaoClimaController : ControllerBase
{
    private readonly IPrevisaoClimaRepository _repo;
    private readonly MLPredictionService _mlService;

    // Atualizado para injetar também o MLPredictionService
    public PrevisaoClimaController(IPrevisaoClimaRepository repo, MLPredictionService mlService)
    {
        _repo = repo;
        _mlService = mlService;
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetById(int id)
    {
        var previsao = await _repo.GetByIdAsync(id);
        if (previsao == null) return NotFound();

        var response = new
        {
            data = previsao,
            links = new[]
            {
                new { rel = "self", href = Url.Action(nameof(GetById), new { id }), method = "GET" },
                new { rel = "update", href = Url.Action(nameof(Update), new { id }), method = "PUT" },
                new { rel = "delete", href = Url.Action(nameof(Delete), new { id }), method = "DELETE" }
            }
        };

        return Ok(response);
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<PrevisaoClima>>> GetAll()
        => Ok(await _repo.GetAllAsync());

    [HttpPost]
    public async Task<IActionResult> Create(PrevisaoClima previsao)
    {
        await _repo.AddAsync(previsao);
        return CreatedAtAction(nameof(GetById), new { id = previsao.Id }, previsao);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(int id, PrevisaoClima previsao)
    {
        if (id != previsao.Id) return BadRequest();
        await _repo.UpdateAsync(previsao);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(int id)
    {
        await _repo.DeleteAsync(id);
        return NoContent();
    }

    // Novo endpoint para previsão de risco via ML
    [HttpPost("prever-risco")]
    public IActionResult PreverRisco([FromBody] PrevisaoInput input)
    {
        var resultado = _mlService.Predict(input);
        return Ok(resultado);
    }
}
