using Enchente.Infrastructure.Data;
using Enchente.Infrastructure.Repositories;
using Enchente.Infrastructure.Messaging; // <- Servi�o RabbitMQ
       // <- Servi�o de ML
using Enchente.Core.Interfaces;
using Microsoft.EntityFrameworkCore;
using AspNetCoreRateLimit;
using Enchente.Infrastructure.Services;

var builder = WebApplication.CreateBuilder(args);

// Banco Oracle
builder.Services.AddDbContext<EnchenteDbContext>(options =>
    options.UseOracle(builder.Configuration.GetConnectionString("OracleConnection")));

// Reposit�rios
builder.Services.AddScoped<ICidadeRepository, CidadeRepository>();
builder.Services.AddScoped<IAlertaEnchenteRepository, AlertaEnchenteRepository>();
builder.Services.AddScoped<IPrevisaoClimaRepository, PrevisaoClimaRepository>();

// Servi�os
builder.Services.AddScoped<IMessagingService, RabbitMqService>();
builder.Services.AddSingleton<MLPredictionService>();

// Controllers e Swagger
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Rate Limiting
builder.Services.AddMemoryCache();
builder.Services.Configure<IpRateLimitOptions>(builder.Configuration.GetSection("IpRateLimiting"));
builder.Services.AddSingleton<IRateLimitConfiguration, RateLimitConfiguration>();
builder.Services.AddInMemoryRateLimiting();

var app = builder.Build();

// Pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseIpRateLimiting();
app.UseAuthorization();

app.MapControllers();

app.Run();

